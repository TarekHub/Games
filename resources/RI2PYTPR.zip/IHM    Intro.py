from tkinter import Tk

Mafenetre = Tk()
Mafenetre.title("Premier test")
Mafenetre.geometry("300x200")
Mafenetre.mainloop()
