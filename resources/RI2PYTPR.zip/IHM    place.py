from tkinter import *
F = Tk()

L1 = Label(text = "11111",bg='white')
L1.place(x=0, y = 10, height=50, width=100)

F.title("Premier test")
F.geometry("300x200")
F.mainloop()
