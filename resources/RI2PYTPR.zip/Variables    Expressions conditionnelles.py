A = B = True
C = D = False
print ( (A or B) and (C or D) )
print( A or ( B and C ) )
print( A and B and (C or D) )
print( (A and B) or (not C) )
print( (not A) or D )
