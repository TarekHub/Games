A="Bonjour"
print( A[1] )
print( A[-4])
print( A[2 :-1])
print( A.upper() )
print( A.replace("jour","soir") )
print( A.find("jour") )
