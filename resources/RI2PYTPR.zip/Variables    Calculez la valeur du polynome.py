# Calculez la valeur du polynôme 3x² + 5x + 1

for k in range(3) :
  print("Entrez une valeur pour x :")
  x = float(input())

  valeur = 3 * x * x + 5 * x + 1

  print("f(x) =",valeur)
