# Faire apparaître une texture de grillage

for i in range(10) :
    for j in range (40) :
        if (i+j) % 2 == 0 :
            print ("X",end="")
        else :
            print( " ", end="")
    print("")
