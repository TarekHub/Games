# Calculer la somme des éléments d'une liste
L = [1, 2, 3, 4, 5, 6 ]

somme = 0
for i in range(len(L)) :
   somme += L[i]

print("Somme totale : " , somme)
